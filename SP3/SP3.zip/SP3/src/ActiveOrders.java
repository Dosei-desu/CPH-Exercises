//Johan
import java.util.LinkedList;

public class ActiveOrders extends IdGenerator {
    private LinkedList<Order> activeOrders;
    int id;

    public ActiveOrders() {
        super.initIdGenerator();
    }

    public void addOrder(boolean _remote, LinkedList<Pizza> _items, Customer _customer) {
        id = super.getRandomId();
        activeOrders.add(new Order(id, _remote, _items, _customer));
    }

    public int getLastOrderId() {
        return id;
    }
}