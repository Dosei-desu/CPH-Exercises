//Timmy & Kris
import java.util.LinkedList;

public class Alfonso extends Restaurant{
    Menu menu;
    ActiveOrders activeOrders;
    Customer currentCustomer;
    Restaurant restaurant = new Restaurant();
    LinkedList<Pizza> customerPizza = new LinkedList<Pizza>();

    Alfonso(Menu menu){
        this.menu = menu;
    }

    public void startOrder(String name, long number){
        this.currentCustomer = new Customer(name, number);
    }

    public void addPizzaToOrderByName(String pizzaName){
        menu.viewPizzaByName(pizzaName);
        for (int i = 0; i < menu.menuPizzas.size(); i++) {
            if(menu.menuPizzas.get(i).getName().toLowerCase().equals(pizzaName.toLowerCase())){
                customerPizza.add(menu.menuPizzas.get(i));
            }
        }
    }

    public void addPizzaToOrderById(int pizzaId){
        menu.viewPizzaByID(pizzaId);
        customerPizza.add(menu.menuPizzas.get(pizzaId-1)); //has to be -1 to match the index
    }

    public void addPizzaToOrderByIngredients(String ingredients){ //need to make function that handles CustomPizzas
        menu.viewPizzaByIngredients(ingredients);
        
        System.out.println("Select pizza (by id):");
        int pizNum = input.nextInt();
        customerPizza.add(menu.menuPizzas.get(pizNum-1));

        //menu.customPizza(ingredients, input, customerPizza);

    }

    public void addOrder(boolean remote, LinkedList<Pizza> items){
        Customer customer = this.currentCustomer;
        activeOrders.addOrder(remote, items, customer); //"is it by phone?" | pizza order | customer
    }

    public void printOrders(){
        String view = "";
        for (int n = 0; n < customerPizza.size(); n++) {
            view += customerPizza.get(n).getId();
            if(customerPizza.get(n).getId() < 10){
                view += " --- Name: \"";
            }else{
                view += " -- Name: \"";
            }
            view += customerPizza.get(n).getName()+"\" -- "+"Ingredients: |";
            for (int i = 0; i < customerPizza.get(n).getIngredients().length; i++) {
                view += customerPizza.get(n).getIngredients()[i];
                if(i < customerPizza.get(n).getIngredients().length-1){
                    view += ", ";
                }
            }
            view += "| -- Price: "+customerPizza.get(n).getPrice()+"kr.\n";
        }
        if(view.equals("")){
            view = "No orders in list.\n";
        }
        System.out.println(view); //prints the long string of stuff created above
    }
}
