//Timmy
public class Customer {
    String name;
    long number;

    public Customer(String name, long number) {
        this.name = name;
        this.number = number;
    }
}
