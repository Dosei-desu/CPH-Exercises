//kris
public class MenuPizza extends Pizza{

    public MenuPizza(String name, int id, String ingredients, double price) {
        super(name, id, ingredients, price);
    }
}
