//Timmy & Kris
public class Mario extends Restaurant{
    Menu menu;

    Mario(Menu menu){
        this.menu = menu;
    }

    public void viewMenu(){
        menu.viewMenu();
    }

    public void viewHistory(){

    }

    public void viewActiveOrders(){

    }
}
